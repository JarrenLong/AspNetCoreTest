﻿namespace IdentitySampleApplication.Code
{
    public enum ModalSize
    {
        Small,
        Large,
        Medium
    }
}
