﻿namespace IdentitySampleApplication.Models
{
    public class ModalHeader
    {
        public string Heading { get; set; }
    }
}